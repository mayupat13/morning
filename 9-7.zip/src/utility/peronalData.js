export const myData = [
  {
    "_id": "60e3b43532f6db9a079937ff",
    "index": 0,
    "guid": "b6ecc7a3-115a-48ee-a51d-992f16ea3802",
    "isActive": true,
    "balance": "$2,304.81",
    "picture": "http://placehold.it/32x32",
    "age": 33,
    "eyeColor": "brown",
    "name": "Compton Sharp",
    "gender": "male",
    "company": "ZILLACTIC",
    "email": "comptonsharp@zillactic.com",
    "phone": "+1 (895) 527-2353",
    "address": "690 Diamond Street, Harborton, District Of Columbia, 5688",
    "about": "Aute deserunt Lorem sint cillum. Dolor ea id sint exercitation in aliquip. Labore cupidatat labore amet voluptate aliqua ea cillum tempor labore dolore Lorem occaecat commodo commodo. Ad aute voluptate occaecat id ipsum nisi laboris pariatur laborum aliquip. Deserunt irure ex adipisicing consequat cupidatat reprehenderit ullamco voluptate nulla pariatur qui nostrud incididunt. Sint adipisicing ullamco voluptate excepteur consectetur ea cupidatat labore.\r\n",
    "registered": "2018-10-30T05:10:57 -06:-30",
    "latitude": -64.557123,
    "longitude": -119.097563,
    "tags": [
      "nisi",
      "culpa",
      "voluptate",
      "veniam",
      "quis",
      "do",
      "amet"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Mcgowan Mcdowell"
      },
      {
        "id": 1,
        "name": "Claire Horne"
      },
      {
        "id": 2,
        "name": "Higgins Mooney"
      }
    ],
    "greeting": "Hello, Compton Sharp! You have 7 unread messages.",
    "favoriteFruit": "banana"
  },
  {
    "_id": "60e3b435f07ba29336511866",
    "index": 1,
    "guid": "0c971c37-673c-406c-a2b1-ee9c0071d0ef",
    "isActive": false,
    "balance": "$3,096.45",
    "picture": "http://placehold.it/32x32",
    "age": 34,
    "eyeColor": "green",
    "name": "John Bolton",
    "gender": "female",
    "company": "SPRINGBEE",
    "email": "johnbolton@springbee.com",
    "phone": "+1 (861) 550-2394",
    "address": "226 Waldane Court, Dargan, Ohio, 1874",
    "about": "Cupidatat proident qui anim deserunt Lorem incididunt magna do occaecat pariatur eu. Dolore et ullamco Lorem proident occaecat laboris laborum nisi et dolor ipsum anim. Voluptate occaecat ex qui id tempor labore quis irure pariatur. Consequat culpa pariatur fugiat excepteur sunt velit. In ut ea et ad ex consequat ut id exercitation sit incididunt. Culpa est excepteur ad nulla deserunt.\r\n",
    "registered": "2018-09-16T12:40:01 -06:-30",
    "latitude": -1.043167,
    "longitude": -129.445941,
    "tags": [
      "anim",
      "commodo",
      "mollit",
      "voluptate",
      "cillum",
      "proident",
      "cupidatat"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Norman Joyner"
      },
      {
        "id": 1,
        "name": "Blankenship Heath"
      },
      {
        "id": 2,
        "name": "Corrine Hawkins"
      }
    ],
    "greeting": "Hello, John Bolton! You have 9 unread messages.",
    "favoriteFruit": "banana"
  },
  {
    "_id": "60e3b4350d2a421f5f13c2aa",
    "index": 2,
    "guid": "61f5fcf7-1296-4555-bd87-9ea17ca31957",
    "isActive": false,
    "balance": "$1,628.97",
    "picture": "https://reactnative.dev/img/tiny_logo.png",
    "age": 28,
    "eyeColor": "brown",
    "name": "Stacy Waller",
    "gender": "female",
    "company": "CONFERIA",
    "email": "stacywaller@conferia.com",
    "phone": "+1 (932) 420-2346",
    "address": "835 Erskine Loop, Sutton, Hawaii, 4061",
    "about": "Qui mollit aliquip et velit elit ut laboris proident adipisicing. Eiusmod nostrud enim ipsum magna. Cillum adipisicing duis ea dolore minim voluptate ad mollit id non dolore id. Tempor culpa in veniam ullamco proident mollit culpa quis aute exercitation ea consectetur labore qui. Laborum adipisicing laboris officia dolore ex sit dolore fugiat laboris ut irure.\r\n",
    "registered": "2020-11-27T03:57:40 -06:-30",
    "latitude": 1.142618,
    "longitude": -49.124285,
    "tags": [
      "aliquip",
      "fugiat",
      "eiusmod",
      "nisi",
      "cupidatat",
      "nisi",
      "enim"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Fulton Herring"
      },
      {
        "id": 1,
        "name": "Theresa Castro"
      },
      {
        "id": 2,
        "name": "Madden Wilkins"
      }
    ],
    "greeting": "Hello, Stacy Waller! You have 6 unread messages.",
    "favoriteFruit": "apple"
  },
  {
    "_id": "60e3b435a8bb7dc577eebd85",
    "index": 3,
    "guid": "780afcb4-4b4a-4e9d-b92d-721bf8a56fc5",
    "isActive": true,
    "balance": "$3,702.27",
    "picture": "http://placehold.it/32x32",
    "age": 23,
    "eyeColor": "green",
    "name": "Chang Rocha",
    "gender": "male",
    "company": "COMTRAK",
    "email": "changrocha@comtrak.com",
    "phone": "+1 (902) 583-2774",
    "address": "241 Lake Street, Dubois, South Carolina, 2008",
    "about": "Tempor est non qui consectetur ad eu deserunt aliquip Lorem veniam ut. Sint aliqua deserunt qui labore. Lorem nostrud dolore quis incididunt. Occaecat tempor laborum id duis esse ipsum pariatur et amet sit in occaecat laboris. Esse magna veniam enim in do labore deserunt veniam exercitation culpa ad magna. Consequat tempor ea dolore exercitation ex in.\r\n",
    "registered": "2015-11-01T04:41:26 -06:-30",
    "latitude": 68.130027,
    "longitude": -162.39532,
    "tags": [
      "amet",
      "aute",
      "consectetur",
      "irure",
      "Lorem",
      "irure",
      "aute"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Elise Hicks"
      },
      {
        "id": 1,
        "name": "Freeman Hudson"
      },
      {
        "id": 2,
        "name": "Joyce Waters"
      }
    ],
    "greeting": "Hello, Chang Rocha! You have 7 unread messages.",
    "favoriteFruit": "banana"
  },
  {
    "_id": "60e3b435beccbce9b75df555",
    "index": 4,
    "guid": "4b95e297-d984-4d58-b35b-65d6f35c3785",
    "isActive": false,
    "balance": "$2,934.33",
    "picture": "http://placehold.it/32x32",
    "age": 31,
    "eyeColor": "brown",
    "name": "Mcclure Bernard",
    "gender": "male",
    "company": "COMTEXT",
    "email": "mcclurebernard@comtext.com",
    "phone": "+1 (828) 539-3745",
    "address": "994 Clifford Place, Brenton, Minnesota, 4962",
    "about": "Deserunt eu excepteur esse ex non ad veniam adipisicing dolore reprehenderit consectetur. Mollit laborum ad fugiat mollit. Anim magna aliquip pariatur mollit. Laborum laboris eu anim nostrud cillum dolor ex incididunt minim nulla laboris amet irure. Ad in irure nulla Lorem reprehenderit consectetur in non tempor id eiusmod sunt minim. Pariatur elit quis nisi aliqua. Et proident nulla incididunt fugiat.\r\n",
    "registered": "2017-03-23T01:49:41 -06:-30",
    "latitude": -3.469761,
    "longitude": 173.063118,
    "tags": [
      "mollit",
      "enim",
      "mollit",
      "aliqua",
      "excepteur",
      "aliqua",
      "est"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Garcia Morrison"
      },
      {
        "id": 1,
        "name": "Natasha Harvey"
      },
      {
        "id": 2,
        "name": "Shirley Oneil"
      }
    ],
    "greeting": "Hello, Mcclure Bernard! You have 8 unread messages.",
    "favoriteFruit": "strawberry"
  }
]